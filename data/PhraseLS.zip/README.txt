This zip package contains two files:

- PhraseLS.txt: The PhraseLS dataset.
- README.txt: This document.

Each line in the PhraseLS.txt file is structured in the following way:

<sentence> <target_complex_phrase> <target_index_in_sentence> <ranking_1>:<candidate_1> <ranking_2>:<candidate_2> ... <ranking_n-1>:<candidate_n-1> <ranking_n>:<candidate_n>

In the format above, each token is separated by a tabulation marker.
The tokens of the target complex phrase are joined by an underscore in the sentence so that it can be retrieved as a single lexical unit.
The PhraseLS.txt file contains 400 lines, each representing a single instance of the dataset.