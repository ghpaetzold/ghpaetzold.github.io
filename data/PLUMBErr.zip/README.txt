1) Introduction

	This package contains BenchLS and NNSVocab, which are integral parts of PLUMBErr: an error identification framework for Lexical Simplification.

2) Content

	- README.txt: This file:
	- BenchLS.txt: The BenchLS dataset.
	- NNSVocab.txt: The NNSVocab list of complex words.
	- PLUMBErr.png: The PLUMBErr methodology.
	
3) BenchLS.txt

	Each line in the BenchLS.txt file follows the following format:
	
	<sentence> <complex_word> <position> <rank_1>:<candidate_substitution_1> ... <rank_n>:<candidate_substitution_n>
	
	Each component is separated by a tabulation marker.
	The <position> component refers to the token position of <complex_word> in <sentence>.
	The <rank_i> components refer to the simplicity ranking of <candidate_substitution_i>.
	The lower the ranking of <candidate_substitution_i>, the simpler it is.
	
4) NNSVocab.txt

	Each line in the NNSVocab.txt file follows the following format:
	
	<complex_word>
	
	Where <complex_word> is a word deemed complex by non-native English speakers.

5) PLUMBErr.png
	
	Consists of an image describing the error identification methodology of PLUMBErr.