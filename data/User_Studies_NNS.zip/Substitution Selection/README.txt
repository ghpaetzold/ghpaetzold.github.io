1) Introduction

	This folder contains the dataset produced in the user study on Substitution Selection described in the paper "Understanding the Lexical Simplification Needs of non-Native Speakers of English".

2) Content
	
	This package contains the following files:
		- README.txt: This file.
		- SS_Annotations.txt: File containing the annotations from the user study on Substitution Selection.
		
3) Format

	All lines in the SS_Annotations.txt file respect the following format:
	
	<sentence> <complex_word> <candidate_substitution> <position> <label>
	
	Each component is separated by a tabulation marker.
	The <position> components refer to the token position of <complex_word> in <sentence>.
	If the <label> marker is equal to "G/M", then the annotator judged that replacing <complex_word> with <candidate_substitution> in <sentence> preserves both its grammaticality and meaning.
	If the <label> marker is equal to "G", then the annotator judged that replacing <complex_word> with <candidate_substitution> in <sentence> preserves only its grammaticality.
	If the <label> marker is equal to "M", then the annotator judged that replacing <complex_word> with <candidate_substitution> in <sentence> preserves only its meaning.
	If the <label> marker is empty, then the annotator judged that replacing <complex_word> with <candidate_substitution> in <sentence> preserves neither its grammaticality or meaning.