1) Introduction

	This folder contains the dataset produced in the user study on Complex Word Identification described in the paper "Understanding the Lexical Simplification Needs of non-Native Speakers of English".

2) Content
	
	This package contains the following files:
		- README.txt: This file.
		- CWI_Annotations.txt: File containing the annotations from the user study on Complex Word Identification.
		
3) Format

	All lines in the CWI_Annotations.txt file respect the following format:
	
	<age> <native_language> <education_level> <proficiency_level> <sentence> <word> <judgment>
	
	Each component is separated by a tabulation marker.
	The <judgment> can receive value "Complex" if <word> in <sentence> was judged complex by the annotator in question, or "Simple" otherwise.