This zip package contains two files:

- NNSeval.txt: The NNSeval evaluation dataset used in the paper's experiments.
- README.txt: This document.

Each line in the NNSeval.txt file is structured in the following way:

<sentence> <target_complex_word> <target_index_in_sentence> <ranking_1>:<candidate_1> <ranking_2>:<candidate_2> ... <ranking_n-1>:<candidate_n-1> <ranking_n>:<candidate_n>

In the format above, each token is separated by a tabulation marker.
The NNSeval.txt file contains 239 lines, each representing a single instance of the dataset.