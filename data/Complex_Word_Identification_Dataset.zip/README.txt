This dataset contains the data produced in the user study mentioned in (Paetzold, 2015)
Each format is formatted as follows:

<age> <native_language> <education_level> <english_proficiency> <sentence> <index_1:complex_word_1> ... <index_n:complex_word_n>

Each bracketed component is separated by a tabulation marker.

References:
Gustavo Henrique Paetzold. Reliable Lexical Simplification for Non-Native Speakers. In the Proceedings of the Student Research Workshop of NAACL, 2015.