Each line in the Common20LS.txt file is structured as:

<id> <age> <native_language> <language_group> <language_family> <education_level> <english_proficiency_level> <sentence_with_gap> <target_complex_word/phrase> <index_of_target_in_sentence> <simpler_candidate> <more_complex_candidate>

Each element is separated by a tabulation marker.