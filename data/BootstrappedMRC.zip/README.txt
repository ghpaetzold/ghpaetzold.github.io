1) Content

	- README.txt: This file.
	- Bootstrapped_Psycholinguistic_Features.txt: File containing bootstrapped Psycholinguistic features for 85,942 words.
	
2) Bootstrapped Psycholinguistic Features

	All lines in the "Bootstrapped_Psycholinguistic_Features.txt" file, except for the first two header lines, are composed of:
	
		<word> <familiarity> <age_of_acquisition> <concreteness> <imagery>
	
	Each token except for <word> is a floating point value obtained by bootstrapping the MRC Psycholinguistic Database.
	The bootstrapping technique used to produce these features is described in the following paper:
	
		@inproceedings{paetzold2016inferring,
		  title={Inferring Psycholinguistic Properties of Words},
		  author={Paetzold, Gustavo Henrique and Specia, Lucia},
		  booktitle={Proceedings of the 2016 NAACL},
		  year={2016}
		}