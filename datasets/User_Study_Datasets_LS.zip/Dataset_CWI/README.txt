1) Introduction

	This folder contains the dataset produced in the user study on Complex Word Identification described in the paper "Understanding the Simplification Needs of Non-Native English Speakers".

2) Content
	
	This package contains the following files:
		- README.txt: This file.
		- Dataset_CWI.txt: File containing the dataset of the user study on Complex Word Identification.
		
3) Format

	All lines in the Dataset_CWI.txt file respect the following format:
	
	<age> <native_language> <education_level> <proficiency_level> <sentence> <position_1>:<complex_word_1> ... <position_n>:<complex_word_n>
	
	Each component is separated by a tabulation marker.
	The <position_i> components refer to the token position of <complex_word_i> in <sentence>.
	If there are not complex words after <sentence>, then the annotator did not find any complex words in the sentence.