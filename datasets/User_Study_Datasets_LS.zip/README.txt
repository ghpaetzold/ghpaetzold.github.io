1) Introduction

	This package contains the datasets produced in the user studies described in the paper "Understanding the Simplification Needs of Non-Native English Speakers".

2) Content
	
	This package contains the following files:
		- README.txt: This file.
		- Dataset_CWI: Folder containing the dataset of the user study on Complex Word Identification.
		- Dataset_SS: Folder containing the dataset of the user study on Substitution Selection.
		- Dataset_SR: Folder containing the dataset of the user study on Substitution Ranking.