1) Introduction

	This folder contains the dataset produced in the user study on Substitution Ranking described in the paper "Understanding the Simplification Needs of Non-Native English Speakers".

2) Content
	
	This package contains the following files:
		- README.txt: This file.
		- Dataset_SR.txt: File containing the dataset of the user study on Substitution Ranking.
		
3) Format

	All lines in the Dataset_CWI.txt file respect the following format:
	
	<age> <native_language> <education_level> <proficiency_level> <sentence> <original_word> <position> <candidate_substitution_1> <candidate_substitution_2> <simplest_candidate>
	
	Each component is separated by a tabulation marker.
	The <position> components refer to the token position of <original_word> in <sentence>.
	The <simplest_candidate> component refers to the candidate substitution which the annotator judged simplest between <candidate_substitution_1> and <candidate_substitution_2>.
	If <simplest_candidate> equals to "The words are equally simple or equally complex.", then <candidate_substitution_1> and <candidate_substitution_2> were judge as equally simple/complex.